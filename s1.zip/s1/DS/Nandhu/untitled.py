print("hello")
a=int(input("enter"))
print(a)
